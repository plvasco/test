## Note
See [examples](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/examples) directory for working examples to reference.

This directory contains build modules to build different services needed. Modification/chages should only be made in main.tf

| Service | Purpose | Directory |
|---------|---------|-----------|
| Linux instance  | This is the compute linux server | [linux-build](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules/linux-build) |
| Windows Instance | This is the compute windows server | [windows-build](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules/windows-build) |
| KMS | This is the key management service for encryption | [kms-build](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules/kms-build) |
| S3 | This is a service for object storage) | [s3-build](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules/s3-build) |
| Security Group |  This builds main and/or security groups and secuirty group rules that can be attached to an instance(s) deployed   | [sg-build](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules/sg-build)    |

## Usage

To deploy each of this services:
Go to the directory of service needed
```bash
cd [directory]
```

```bash
$ terraform init
$ terraform plan
$ terraform apply
```