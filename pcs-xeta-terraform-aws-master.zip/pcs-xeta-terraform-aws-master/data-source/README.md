This configuration contains existing resources/services in Xeta cloud.

This includes;

- VPC ID
- Subnets
- AMI
- Route table
- Security Groups