Configuration in this directory creates:

- Linux Module (Includes EC2 Instance, EBS, EFS, Key_Pair)
- KMS Module for EBS and EFS encryption
- Security Group Module that will be attached to the linux server
- Data-Source module pulls existing resources within the CPI 



## Note about the Key Pair

The key pair is dynamic and specific to the user deploying or implementing the resource. 

```hcl

resource "aws_key_pair" "ec2_key" {
  key_name   = var.keypair_name
  public_key = file("~/.ssh/id_rsa.pub")
}
```

The "public_key" is the public key in the user's ~/.ssh/id_rsa.pub with the pem file been "id_rsa".
If this doesn't exist, please generate an rsa keypair id_rsa & id_rsa.pub
The generated or existing private key will be used to "ssh" into the remote server as follow;

```bash
ssh -i "id_rsa" [server_private_ip]
```

## List of available EC2 types

- t3.small 
- t3.medium 
- t3.large 
- t3.xlarge 
- t3.2xlarge 
- GP / General Purpose

## Available Regions

- us-gov-east-1
- us-gov-west-1

* NOTE:
To deploy to multiple regions, update to the region in the provider with the region resources should be deployed to.

```hcl
provider "aws" {
  max_retries = 1
  region      = "us-gov-east-1"  # modify this line as needed
  access_key  = var.AWS_ACCESS_KEY
  secret_key = var.AWS_SECRET_KEY
  assume_role {
    # The role ARN within Account B to AssumeRole into.
    role_arn    = var.AWS_ROLE_ARN
    # The Automation Account ID to assume
    external_id = var.AWS_ROLE_EXTERNAL_ID
  }
}
```

## List of Subnets and Availability zone in both regions of the CPIs

| Subnet         |  AZ        |
|----------------|------------|
| Priv-1-subnet |  us-gov-east-1a |
| Priv-2-subnet  | us-gov-east-1b |
| Priv-3-subnet  | us-gov-east-1C |
| Priv-4-subnet  | us-gov-east-1a |

| Subnet         |  AZ        |
|----------------|------------|
| Priv-1-subnet |  us-gov-west-1a |
| Priv-2-subnet  | us-gov-west-1b |
| Priv-3-subnet  | us-gov-west-1C |
| Priv-4-subnet  | us-gov-west-1a |

## Usage

To run this you need to execute:

```bash
$ terraform init
$ terraform plan
$ terraform apply
```

### Outputs
| Output         |  Description                       |
|----------------|------------------------------------|
| Instance state | The current state of the instance  |
| Private IP  | The private ip of the instance  |
| ssh key | The key_pair name to ssh into server  |
| Host_FQDN | The complete domain name of the host  |
