Content-Type: multipart/mixed; boundary="==BOUNDARY=="
MIME-Version:  1.0
--==BOUNDARY==
Content-Type: text/cloud-boothook; charset="us-ascii"

#!/bin/bash -xe
exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1

#Set AWS global variables
export AWS_DEFAULT_REGION=$(curl http://169.254.169.254/latest/meta-data/placement/region)
region=$AWS_DEFAULT_REGION

#Set the proxy hostname and find our VPC CIDRs
PROXY="proxy.ext.ray.com:80"
MAC=$(curl -s http://169.254.169.254/latest/meta-data/mac/)
VPC_CIDR=$(curl -s http://169.254.169.254/latest/meta-data/network/interfaces/macs/$MAC/vpc-ipv4-cidr-blocks | xargs | tr ' ' ',')

#Create the docker systemd directory
mkdir -p /etc/systemd/system/docker.service.d

#Configure yum to use the proxy
cloud-init-per instance yum_proxy_config cat << EOF >> /etc/yum.conf
proxy=http://$PROXY
EOF

#Set the proxy for future processes, and use as an include file
cloud-init-per instance proxy_config cat << EOF >> /etc/environment
http_proxy=http://$PROXY
https_proxy=http://$PROXY
HTTP_PROXY=http://$PROXY
HTTPS_PROXY=http://$PROXY
no_proxy=.ray.com,127.0.0.1,localhost,169.254.169.254,172.20.0.0/16,$VPC_CIDR,.internal,.$region.eks.amazonaws.com,api.ecr.$region.amazonaws.com,dkr.ecr.$region.amazonaws.com,ec2.$region.amazonaws.com,.s3.$region.amazonaws.com,s3.amazonaws.com
NO_PROXY=.ray.com,127.0.0.1,localhost,169.254.169.254,172.20.0.0/16,$VPC_CIDR,.internal,.$region.eks.amazonaws.com,api.ecr.$region.amazonaws.com,dkr.ecr.$region.amazonaws.com,ec2.$region.amazonaws.com,.s3.$region.amazonaws.com,s3.amazonaws.com
EOF

#Configure docker with the proxy
cloud-init-per instance docker_proxy_config tee <<EOF /etc/systemd/system/docker.service.d/proxy.conf >/dev/null
[Service]
EnvironmentFile=/etc/environment
EOF

#Configure the kubelet with the proxy
cloud-init-per instance kubelet_proxy_config tee <<EOF /etc/systemd/system/kubelet.service.d/proxy.conf >/dev/null
[Service]
EnvironmentFile=/etc/environment
EOF

#Reload the daemon and restart docker to reflect proxy configuration at launch of instance
cloud-init-per instance reload_daemon systemctl daemon-reload 
cloud-init-per instance enable_docker systemctl enable --now --no-block docker

#Find our Cluster Name and write it in a file for later use
instance_id=$(curl http://169.254.169.254/latest/meta-data/instance-id)
nametag=$(aws ec2 describe-tags --filters "Name=resource-id,Values=$instance_id" "Name=key,Values=eks:cluster-name")
ClusterName=$(echo $nametag | python -c 'import json,sys; print json.load(sys.stdin)["Tags"][0]["Value"]')
echo "export ClusterName=$ClusterName" > /etc/eks/clustername

--==BOUNDARY==
Content-Type:text/x-shellscript; charset="us-ascii"

#!/bin/bash
set +o xtrace

#Set the proxy variables before running the bootstrap.sh script
set -a
source /etc/environment
source /etc/eks/clustername

/etc/eks/bootstrap.sh $ClusterName ${BootstrapArguments}

--==BOUNDARY==--