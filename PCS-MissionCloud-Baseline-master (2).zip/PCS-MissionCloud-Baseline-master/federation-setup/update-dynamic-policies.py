import subprocess
import argparse
import shlex
import sys

# Setup the command arguements
parser = argparse.ArgumentParser()

parser.add_argument('-p', '--profile', help='Profile Name')

args = parser.parse_args()
# Use a default value for profile if non was given at the command line
if not args.profile:
    #profile_name = 'default'
    profile_name = 'default'
else:
    profile_name = args.profile


#################################################################################
# Definitions

# Definition to format subprocess arguements for the appropriate OS
def format_subprocess_args(command_line):
    if sys.platform.lower().startswith('win'):
        args = shlex.split(command_line)
    else:
        if command_line.startswith('python '):
            lnx_python3_command = command_line.replace('python', 'python3', 1)
            args = shlex.split(lnx_python3_command)
        else:
            args = command_line
    return args

################################################################################
# Main


# run each dynamic policy
print('-'*50)

subprocess.run(format_subprocess_args('python generate-02_Deny_Launch_in_VPC.py --profile=' + profile_name))
print()
subprocess.run(format_subprocess_args('python generate-02_Deny_S3_to_Ext_Net.py --profile=' + profile_name))
print()
subprocess.run(format_subprocess_args('python generate-02_Enforce_Encryption.py --profile=' + profile_name))
print()
subprocess.run(format_subprocess_args('python generate-02_Allow_Encryption_Key_Usage.py --profile=' + profile_name))
print()
    
print('-'*50)

# Make sure EMR default roles are deployed
print('Verifying default Roles for EMR are deployed')
subprocess.run(format_subprocess_args('aws emr create-default-roles --profile ' + profile_name), shell=True)
print('**** Processing is Complete ****')