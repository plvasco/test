import json
import boto3
import argparse
import datetime

# Setup the command arguements
parser = argparse.ArgumentParser()

parser.add_argument('-p', '--profile', help='Profile Name')
parser.add_argument('-b', '--base', help='Base Path')

args = parser.parse_args()

# Use a default value for profile if non was given at the command line
if not args.profile:
    #profile_name = 'default'
    profile_name = 'saml'
else:
    profile_name = args.profile

# Construct the path and file string using either a default or command line path
if not args.base:
    base_path = ''
else:
    base_path = args.base

file = '02_Deny_S3_to_Ext_Net.tf'

if not base_path:
    path = file
elif base_path.endswith('\\'):
    path = base_path + file
else:
    path = base_path + '\\' + file

# Definition to write the file
def write_policy(policy, path):
    new_terraform_file = open(path, mode='wt')
    for line in policy:
        #print(str(line))
        new_terraform_file.write(str(line) + '\n')
    
    new_terraform_file.close()

# Definition to read the file
def read_policy(path):
    read_file = open(path, 'r')
    terraform_file = read_file.read().splitlines()
    read_file.close()
    return terraform_file

# definition to serialize datetime.datetime strings in json
def datetime_handler(x): 
     if isinstance(x, datetime.datetime): 
         return x.isoformat() 
     raise TypeError("Unknown type")  


# Start using the temporary token and create the encrypted images
session = boto3.Session(profile_name=profile_name)

# Initialze a client session
ec2_client = session.client('ec2')
sts_client = session.client('sts')

# Get the account number
ident_resp = sts_client.get_caller_identity()
account_id = ident_resp['Account']

# Contruct _Deny_S3_to_Ext_Net iam policy
print('Constructing _Deny_Service_to_External')

vpce_results = ec2_client.describe_vpc_endpoints()
#print(json.dumps(vpce_results['VpcEndpoints'], default=datetime_handler, indent=4))

s3_vpce_list = []
dynamodb_vpce_list = []
secretsmanager_vpce_list = []
for vpce in vpce_results['VpcEndpoints']:
    if vpce['ServiceName'] == 'com.amazonaws.us-gov-west-1.s3':
        s3_vpce_list.append(vpce['VpcEndpointId'])
    elif vpce['ServiceName'] == 'com.amazonaws.us-gov-west-1.dynamodb':
        dynamodb_vpce_list.append(vpce['VpcEndpointId'])
    elif vpce['ServiceName'] == 'com.amazonaws.us-gov-west-1.secretsmanager':
        secretsmanager_vpce_list.append(vpce['VpcEndpointId'])
    #vpce_list.append(vpce['VpcEndpointId'])

if s3_vpce_list:

    terraform_file = []
    terraform_file.append( '#################')
    terraform_file.append( '# Create Policy')
    terraform_file.append( '')
    terraform_file.append( 'resource "aws_iam_policy" "_Deny_S3_to_Ext_Net" {')
    terraform_file.append( '    name = "_Deny_Service_to_External"')
    terraform_file.append( '    policy = <<EOF')
    terraform_file.append( '{')
    terraform_file.append( '    "Version": "2012-10-17",')
    terraform_file.append( '    "Statement": [')
    terraform_file.append( '        {')
    terraform_file.append( '            "Effect": "Deny",')
    terraform_file.append( '            "Action": "s3:*",')
    terraform_file.append( '            "Resource": "*",')
    terraform_file.append( '            "Condition": {')
    terraform_file.append( '                "NotIpAddress": {')
    terraform_file.append( '                    "aws:SourceIp": [')
    terraform_file.append( '                        "199.46.188.0/26",')
    terraform_file.append( '                        "199.46.182.0/26",')
    terraform_file.append( '                        "199.46.236.0/26",')
    terraform_file.append( '                        "199.46.196.128/26",')
    terraform_file.append( '                        "199.46.250.128/26",')
    terraform_file.append( '                        "199.46.249.128/26",')
    terraform_file.append( '                        "199.46.251.128/26",')
    terraform_file.append( '                        "128.13.4.0/26",')
    terraform_file.append( '                        "128.13.8.0/26"')
    terraform_file.append( '                    ]')
    terraform_file.append( '                },')
    terraform_file.append( '                "Bool": {')
    terraform_file.append( '                    "aws:ViaAWSService": "false"')
    terraform_file.append( '                },')
    terraform_file.append( '                "StringNotEquals": {')
    terraform_file.append( '                    "aws:SourceVpce": [')
    for item_count, vpce_id in enumerate(s3_vpce_list, 1):
        if item_count == len(s3_vpce_list):
            terraform_file.append( '                        "' + vpce_id + '"')
        else:
            terraform_file.append( '                        "' + vpce_id + '",')
    terraform_file.append( '                    ]')
    terraform_file.append( '                }')
    terraform_file.append( '            }')
    terraform_file.append( '        },')
    terraform_file.append( '        {')
    terraform_file.append( '            "Effect": "Deny",')
    terraform_file.append( '            "Action": "dynamodb:*",')
    terraform_file.append( '            "Resource": "*",')
    terraform_file.append( '            "Condition": {')
    terraform_file.append( '                "NotIpAddress": {')
    terraform_file.append( '                    "aws:SourceIp": [')
    terraform_file.append( '                        "199.46.188.0/26",')
    terraform_file.append( '                        "199.46.182.0/26",')
    terraform_file.append( '                        "199.46.236.0/26",')
    terraform_file.append( '                        "199.46.196.128/26",')
    terraform_file.append( '                        "199.46.250.128/26",')
    terraform_file.append( '                        "199.46.249.128/26",')
    terraform_file.append( '                        "199.46.251.128/26",')
    terraform_file.append( '                        "128.13.4.0/26",')
    terraform_file.append( '                        "128.13.8.0/26"')
    terraform_file.append( '                    ]')
    terraform_file.append( '                },')
    terraform_file.append( '                "Bool": {')
    terraform_file.append( '                    "aws:ViaAWSService": "false"')
    terraform_file.append( '                },')
    terraform_file.append( '                "StringNotEquals": {')
    terraform_file.append( '                    "aws:SourceVpce": [')
    for item_count, vpce_id in enumerate(dynamodb_vpce_list, 1):
        if item_count == len(dynamodb_vpce_list):
            terraform_file.append( '                        "' + vpce_id + '"')
        else:
            terraform_file.append( '                        "' + vpce_id + '",')
    terraform_file.append( '                    ]')
    terraform_file.append( '                }')
    terraform_file.append( '            }')
    terraform_file.append( '        },')
    terraform_file.append( '        {')
    terraform_file.append( '            "Effect": "Deny",')
    terraform_file.append( '            "Action": "secretsmanager:*",')
    terraform_file.append( '            "Resource": "*",')
    terraform_file.append( '            "Condition": {')
    terraform_file.append( '                "NotIpAddress": {')
    terraform_file.append( '                    "aws:SourceIp": [')
    terraform_file.append( '                        "199.46.188.0/26",')
    terraform_file.append( '                        "199.46.182.0/26",')
    terraform_file.append( '                        "199.46.236.0/26",')
    terraform_file.append( '                        "199.46.196.128/26",')
    terraform_file.append( '                        "199.46.250.128/26",')
    terraform_file.append( '                        "199.46.249.128/26",')
    terraform_file.append( '                        "199.46.251.128/26",')
    terraform_file.append( '                        "128.13.4.0/26",')
    terraform_file.append( '                        "128.13.8.0/26"')
    terraform_file.append( '                    ]')
    terraform_file.append( '                },')
    terraform_file.append( '                "Bool": {')
    terraform_file.append( '                    "aws:ViaAWSService": "false"')
    terraform_file.append( '                },')
    terraform_file.append( '                "StringNotEquals": {')
    terraform_file.append( '                    "aws:SourceVpce": [')
    for item_count, vpce_id in enumerate(secretsmanager_vpce_list, 1):
        if item_count == len(secretsmanager_vpce_list):
            terraform_file.append( '                        "' + vpce_id + '"')
        else:
            terraform_file.append( '                        "' + vpce_id + '",')
    terraform_file.append( '                    ]')
    terraform_file.append( '                }')
    terraform_file.append( '            }')
    terraform_file.append( '        }')
    terraform_file.append( '    ]')
    terraform_file.append( '}')
    terraform_file.append( 'EOF')
    terraform_file.append( '}')
    terraform_file.append( '')
    terraform_file.append( '###############')
    terraform_file.append( '# Attach Policy')
    terraform_file.append( '')
    terraform_file.append( 'resource "aws_iam_policy_attachment" "attach_Deny_S3_to_Ext_Net" {')
    terraform_file.append( '    name = "_Deny_service_to_external"')
    terraform_file.append( '    roles = concat(')
    terraform_file.append( '        var.tc-r-deny-ext-netwrk,')
    terraform_file.append( '        var.mt-r-deny-ext-netwrk,')
    terraform_file.append( '        [')
    terraform_file.append( '            aws_iam_role.cloudadmin.name,')
    terraform_file.append( '            aws_iam_role.securityadmin.name,')
    terraform_file.append( '            aws_iam_role.devops.name,')
    terraform_file.append( '            aws_iam_role.dvcldsysadmin.name,')
    terraform_file.append( '            aws_iam_role.eadvcldsysadmin.name,')
    terraform_file.append( '            aws_iam_role.auditor.name,')
    terraform_file.append( '            aws_iam_role.costmanager.name,')
    terraform_file.append( '            aws_iam_role.tenantsysadmin.name,')
    terraform_file.append( '            aws_iam_role.projectowner.name,')
    terraform_file.append( '            aws_iam_role.instance_devops.name,')
    terraform_file.append( '            aws_iam_role.instance_tenantsysadmin.name')
    terraform_file.append( '        ]')
    terraform_file.append( '    )')
    terraform_file.append( '    users = concat(')
    terraform_file.append( '        var.tc-u-deny-ext-netwrk,')
    terraform_file.append( '        var.mt-u-deny-ext-netwrk,')
    terraform_file.append( '        [')
    terraform_file.append( '        ]')
    terraform_file.append( '    )')
    terraform_file.append( '    policy_arn = aws_iam_policy._Deny_S3_to_Ext_Net.arn')
    terraform_file.append( '}')

    #for line in terraform_file:
    #    print(line)
    
    # Determine if the file exists and needs to be updated.
    print('Checking for existing file')
    try:
        previous_terraform_file = read_policy(path)
        print('File exists')
    except:
        print('No File found')
        previous_terraform_file = []

    if previous_terraform_file == terraform_file:
         print('Terraform file is up to date. No Change made')
    else:
        print('Writing new Terraform file.')
        write_policy(terraform_file, path)
