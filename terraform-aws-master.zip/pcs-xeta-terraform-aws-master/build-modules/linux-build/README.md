## Note
See [examples](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/examples) directory for working examples to reference



Configuration in this directory creates:

- Linux Module (Includes EC2 Instance, EBS, EFS, Key_Pair and Route53 record) based on the list of EC2-TYPES specified
- KMS Module for EBS and EFS encryption
- Security Group Module that will be attached to the linux server
- Data-Source module pulls existing resources within the CPI 

## DEMO

  ## NOTE:
To deploy to multiple regions, update to the region in the provider with the region resources should be deployed to.

```hcl
provider "aws" {
  max_retries = 1
  region      = "us-gov-east-1"  # modify this line as needed
  access_key  = var.AWS_ACCESS_KEY
  secret_key = var.AWS_SECRET_KEY
  assume_role {
    # The role ARN within Account B to AssumeRole into.
    role_arn    = var.AWS_ROLE_ARN
    # The Automation Account ID to assume
    external_id = var.AWS_ROLE_EXTERNAL_ID
  }
}

module "data-source" {
  source                  = "../../data-source"

  #### for dev01  (d32d1-dtcp01)
  vpc_id                  = "dev01-us2-d32d1"
  domain_name             = "d32d1-dtcp01.wg1.aws.ray.com"  
  # ami_name                = "Linux.RHEL.8-*"
  # ami_owner               = "309595011899"   ### self or AWS account ID
  ami_owner               = "self"
  ami_name                = "RMD_RHEL_8_Base_IRAMP_*"

###   ## npd01   (d33d1-dtcp01)
  # vpc_id                  = "npd01-us2-d33d1"  
  # ami_name                  = "test-image"
 # domain_name           = "d33d1-dtcp01.wg1.aws.ray.com"  ### npd01 domain name
}

### This module block creates KMS for EBS and EFS encryption

module "kms" {
  source               = "../../KMS"
  user                 = "nrp0257218"
  key_alias            = "test-PCS-KMS"
  organization         = "PCS"
  environment          = "DEV"
}

##### This module block creates the main security group that will be attached to the linux server

module "main-security-group" {
    create                                      = true
    source                                      = "../../security-group"
    sg_name                                     = "RMD-SG"
    vpc_id                                      = module.data-source.vpc_id
    user                                        = "nrp0257218"
    ingress_cidr_blocks                         = [module.data-source.vpc_cidr_block, "10.50.5.0/24", "138.127.247.30/32"]
    egress_cidr_blocks                          = [module.data-source.vpc_cidr_block]
    ingress_rules                               = ["rdp-tcp", "ssh-tcp", "ldap-tcp", "ldap-udp", "smb-tcp", "ntp-udp", "kdc-tcp", "kdcs-tcp"]
    egress_rules                                = ["rdp-tcp", "ssh-tcp", "ldap-tcp", "ldap-udp", "smb-tcp", "ntp-udp", "kdc-tcp"]

## if a security group with source sg is needed, change the below flag to "true" 
## and add the rules needed.
    create_sg_with_source                       = false
    ingress_with_source_security_group_id       = ["rdp-tcp", "nfs-tcp"]
    egress_with_source_security_group_id        = ["all-all"]

}

#### This module block deploys the linux server, EFS mounted to the server, EBS and key pair for ssh and 

module "ec2_instance" {
    source               = "../../linux"
    host_name            = "test-xeta-lin"
    ami_name             = module.data-source.ami_id
    ebs_name             = "test-xeta-lin"
    ebs_type             = "gp3"
    ebs_device_name      = "/dev/xvdb"
    ebs_az               = module.data-source.priv_1_subnet_az
    ebs_size             = "100"
    ebs_snapshot         = false
    ec2_type             = ["t3.medium"]     ## THE number of ec2_type(s) specified here will be the number of servers deployed

    create_efs           = false
    efs_throughput       = "bursting"    ### bursting or provisioned
    efs_name             = "test-xeta-lin"           #### provide efs_create true, input efs name

    keypair_name         = "id_rsa"
    key_alias            = module.kms.key_alias
    kms_key_arn          = module.kms.key_arn
    root_vol_type        = "gp3"
    root_vol_size        = "100"
    security-group       = [module.main-security-group.main_security_group_id]
    subnet_id            = module.data-source.priv_1_subnet
    subnet_ids           = module.data-source.subnet_ids
    ### User = Individual/username of the person deploying the resources
    user                 = "nrp0257218"
    user_data            = "${base64encode(data.template_file.bootstrap.rendered)}"
    vpc_id               = module.data-source.vpc_id

    ### Route53 ###
    domain_name          = module.data-source.domain_name
    route53_zone_id      = module.data-source.route53_zone_id


## TAGS ##
    organization         = "PCS"
    environment          = "DEV"
    costcenter           = "24477"
    resource_level       = "RMD Cloud Direct"
    business_unit        = "RMD"
    project              = "PCS"
    data_class           = "USC"
    shutdown_protect     = false
    backup               = true
    backup_days          = "60"
}


```

## Note about the Key Pair

The key pair is dynamic and specific to the user deploying or implementing the resource. 

```hcl

resource "aws_key_pair" "ec2_key" {
  key_name   = var.keypair_name
  public_key = file("~/.ssh/id_rsa.pub")
}
```

The "public_key" is the public key in the user's ~/.ssh/id_rsa.pub with the pem file been "id_rsa".
If this doesn't exist, please generate an rsa keypair id_rsa & id_rsa.pub
The generated or existing private key will be used to "ssh" into the remote server as follow;

```bash
ssh -i "id_rsa" [server_private_ip]
```

## Usage

To run this you need to execute:

```bash
$ terraform init
$ terraform plan
$ terraform apply
```

## List of available EC2 types

- t3.small 
- t3.medium 
- t3.large 
- t3.xlarge 
- t3.2xlarge 
- GP / General Purpose

## Available Regions

- us-gov-east-1
- us-gov-west-1



## List of Subnets and Availability zone in both regions of the CPIs

| Subnet         |  AZ        |
|----------------|------------|
| Priv-1-subnet |  us-gov-east-1a |
| Priv-2-subnet  | us-gov-east-1b |
| Priv-3-subnet  | us-gov-east-1C |
| Priv-4-subnet  | us-gov-east-1a |

| Subnet         |  AZ        |
|----------------|------------|
| Priv-1-subnet |  us-gov-west-1a |
| Priv-2-subnet  | us-gov-west-1b |
| Priv-3-subnet  | us-gov-west-1C |
| Priv-4-subnet  | us-gov-west-1a |


### Outputs
| Output         |  Description                       |
|----------------|------------------------------------|
| Instance state | The current state of the instance  |
| Private IP  | The private ip of the instance  |
| ssh key | The key_pair name to ssh into server  |
| Host_FQDN | The complete domain name of the host  |
