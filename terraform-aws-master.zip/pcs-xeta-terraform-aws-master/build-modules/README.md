## Note
See [examples](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/development/examples) directory for working examples to reference.


This directory contains build modules to build different services needed. 

| Service | Purpose | Directory |
|---------|---------|-----------|
| Linux instance  | This is the compute server | ./linux-build |
| KMS | This is the key management service for encryption | ./KMS |
| Storage | This contains different storage services (S3, FSX, Storage GTW) | ./storage-build |
| Security-group |  This builds main and/or security groups and secuirty group rules that can be attached to an instance    | ./sg-build    |

## Usage

To deploy each of this services:
Go to the directory of service needed
```bash
cd [directory]
```

```bash
$ terraform init
$ terraform plan
$ terraform apply
```