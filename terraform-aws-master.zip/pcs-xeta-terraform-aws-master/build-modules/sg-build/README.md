## Note
See [examples](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/development/examples) directory for working examples to reference

Configuration in this directory creates:

- Main Security group
- Security Group Rule



### List of Rules for Ingress and Egress EC2
The following are the list of rules with ports. Feel free to add to the list if needed rule is not on this list and specify based on the current definition.
To add;
```bash
cd ../../security-group/ports.tf
```

|  Description      | Protocol        | Port   |
|-------------------|-----------------|--------|
| DNS               | TCP             | 53     |
| DNS               | UDP             | 53     |
| HTTP              | TCP             | 80     |
| HTTPS             | TCP             | 443    |
| kubernetes-api    | TCP             | 6443   |
| LDAP              | TCP             | 389    |
| LDAPS             | TCP             | 636    |
| MYSQL             | TCP             | 3306   |
| NFS               | TCP             | 2049   |
| POSTGREL-SQL      | TCP             | 5432   |
| RDP               | TCP             | 3389   |
| SSH               | TCP             | 22     |
| LDAP              | TCP             | 636    |
| ALL               | ALL (TCP/UDP)   | -1     |
| ALL               | TCP             | 0-65535    |
| ALL               | UDP             | 0-65535    |
| ALL               | ICMP             | -1    |


##  Note
Rules must be specified in the format "[description-protocol]" 
If a security group rule with source security group is needed, set "create_sg_with_source" to true.




