## Note
See [examples](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/examples) directory for working examples to reference.

## Terraform Modules

Terraform modules are reusable code that can be called to provision resources in AWS. The following modules are available for use.

## pcs-xeta-terraform-aws

  ## NOTE
    
  The entire repo can be pulled to be used as a demo. Changes can be made to the main.tf files in the [build-modules](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules) directories for any demo you like. 

| Module Name | Purpose | Config Directory |
|--------------|---------|-----------|
| Build Modules | This directory contain modules to buid services needed. This is where parameters can be changed and used to build the configured services in the following directories | [./build-modules](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules) |
| Data Module | Used to gather existing data from within the VPC. Includes subnets, AMI, and security groups | [./data-source](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/data-source) |
| Security Group Module | Used to create baseline security groups in a VPC. To provison, go to [./build-modules/sg-build](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules/sg-build)  | [./security-group](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/security-group) |
| Linux Module | Used to build a linux instance from an ami that can be joined to the domain. This module includes EFS, key-pair, route53 and EBS. To provison, go to [./build-modules/linux-build](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules/linux-build)  | ./linux |
| KMS Module | used to create KMS key for encryption. To provison KMS, go to [./build-modules/kms-build](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules/kms-build) | ./KMS  |
| S3 Module | contain configurations to build S3 for object storage. To provison, go to [./build-modules/s3-build](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules/s3-build) | ./s3  |
| Windows Module | Used to build a windows instance from an ami that can be joined to the domain. To provison, go to [./build-modules/windows-build](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/master/build-modules/windows-build) | ./windows |


## Sample main.tf

  
The following example shows how to call child modules in another module and referencing outputs in Terraform. Please see the module README for the expected inputs and available outputs.  
  
```hcl

module "data-source" {
  source                  = "../data-source"
  vpc_id                  = var.vpc_id
  ami_name                = var.ami_name
}

resource "aws_instance" "linux_instance" {
  ami                           = module.data-source.ami_id
  instance_type                 = var.ec2_type
  user_data                     = "${base64encode(data.template_file.bootstrap.rendered)}"
  subnet_id                     = "${module.data-source.priv_1_subnet}"
  key_name                      = "${aws_key_pair.ec2_key.id}"
  vpc_security_group_ids        = [module.data-source.platformsg]
}
```
RAYTHEON PROPRIETARY

This document contains data or information proprietary to Raytheon Company and is restricted to use only by persons authorized by Raytheon Company in writing to use it. Disclosure to unauthorized persons would likely cause substantial competitive harm to Raytheon Company's business position.

Neither said document nor its contents shall be furnished or disclosed to or copied or used by persons outside Raytheon Company without the express written approval of Raytheon Company.

WARNING – This repository contains Technical Data and / or technology whose export or disclosure to Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22 C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).

This document CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.

Violations are subject to severe criminal penalties.

Unpublished Work - Copyright Raytheon Company. (UNCLASSIFIED)

