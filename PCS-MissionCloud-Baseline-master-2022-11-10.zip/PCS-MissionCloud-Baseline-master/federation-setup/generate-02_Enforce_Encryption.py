import json
import boto3
import argparse
import re

# Setup the command arguements
parser = argparse.ArgumentParser()

parser.add_argument('-b', '--base', help='Base Path')
parser.add_argument('-p', '--profile', help='Profile Name')

args = parser.parse_args()

# Use a default value for profile if non was given at the command line
if not args.profile:
    profile_name = 'saml'
else:
    profile_name = args.profile

# Construct the path and file string using either a default or command line path
if not args.base:
    base_path = ''
else:
    base_path = args.base

file = '02_Enforce_encryption.tf'

if not base_path:
    path = file
elif base_path.endswith('\\'):
    path = base_path + file
else:
    path = base_path + '\\' + file

# Definition to write the file
def write_policy(policy, path):
    new_terraform_file = open(path, mode='wt')
    for line in policy:
        #print(str(line))
        new_terraform_file.write(str(line) + '\n')
    
    new_terraform_file.close()

# Definition to read the file
def read_policy(path):
    read_file = open(path, 'r')
    terraform_file = read_file.read().splitlines()
    read_file.close()
    return terraform_file

# Start using the temporary token and create the encrypted images
session = boto3.Session(profile_name=profile_name)

###########################################
# Figure out the CMK key(s) for the account

# Check for enabled key state
def key_state(key_id):
    kms_key_response = kms_client.describe_key(KeyId = key_id)
    kms_state = kms_key_response['KeyMetadata']['KeyState']
    if kms_state == 'Enabled':
        return True
    else:
        return False

# Get the account number
sts_client = session.client('sts')
ident_resp = sts_client.get_caller_identity()
account_id = ident_resp['Account']

# Return all kms aliases
kms_client = session.client('kms')
alias_responses = kms_client.list_aliases()

# Copy only enabled aliases with -CMK- in the name
cmk_aliases = {'Aliases':[]}
for alias in alias_responses['Aliases']:
    state = False
    if re.match('^alias/Tenant...-CMK*', alias['AliasName']):
        state = key_state(alias['AliasArn'])
        if state:
            cmk_aliases['Aliases'].append(alias)

# Error Check if no enable CMK found
if len(cmk_aliases['Aliases']) == 0:
    print('Cannot locate the imported Customer Managed Key for encryption.')
    print('Verify in the console the alias for the CMK and it is fully enable.')
    print('exiting script ...')
    exit(1)

#print(json.dumps(cmk_aliases, indent = 4))

# Contruct _Deny_S3_to_Ext_Net iam policy
print('Constructing _Enforce_Encryption')

#vpc_results = ec2_client.describe_vpcs()
##print(vpc_results)

terraform_file = []
terraform_file.append( '#################')
terraform_file.append( '# Create Policy')
terraform_file.append( '')
terraform_file.append( 'resource "aws_iam_policy" "_Enforce_Encryption" {')
terraform_file.append( '    name = "_Enforce_Encryption"')
terraform_file.append( '    policy = <<EOF')
terraform_file.append( '{')
terraform_file.append( '    "Version": "2012-10-17",')
terraform_file.append( '    "Statement": [')
terraform_file.append( '        {')
terraform_file.append( '            "Effect": "Deny",')
terraform_file.append( '            "Action": "elasticfilesystem:CreateFileSystem",')
terraform_file.append( '            "Resource": "*",')
terraform_file.append( '            "Condition": {')
terraform_file.append( '                "Bool": {')
terraform_file.append( '                    "elasticfilesystem:Encrypted": "false"')
terraform_file.append( '                }')
terraform_file.append('            }')
terraform_file.append( '        },')
terraform_file.append( '        {')
terraform_file.append( '            "Effect": "Deny",')
terraform_file.append( '            "Action": "s3:PutObject",')
terraform_file.append( '            "Resource": "arn:aws-us-gov:s3:::*",')
terraform_file.append( '            "Condition": {')
terraform_file.append( '                "StringNotEquals": {')
terraform_file.append( '                    "s3:x-amz-server-side-encryption": "aws:kms"')
terraform_file.append( '                }')
terraform_file.append( '            }')
terraform_file.append( '        },')
terraform_file.append( '        {')
terraform_file.append( '            "Effect": "Deny",')
terraform_file.append( '            "Action": "s3:PutObject",')
terraform_file.append( '            "Resource": "arn:aws-us-gov:s3:::*",')
terraform_file.append( '            "Condition": {')
terraform_file.append( '                "StringNotEquals": {')
terraform_file.append( '                    "s3:x-amz-server-side-encryption-aws-kms-key-id": [')
for index, alias_arn in enumerate(cmk_aliases['Aliases'], 1):
    if len(cmk_aliases['Aliases']) == index:
        terraform_file.append( '                        "arn:aws-us-gov:kms:us-gov-west-1:' + account_id + ':key/' + alias_arn['TargetKeyId'] + '",')
        terraform_file.append( '                        "' + alias_arn['AliasArn'] + '"')
    else:
        terraform_file.append( '                        "arn:aws-us-gov:kms:us-gov-west-1:' + account_id + ':key/' + alias_arn['TargetKeyId'] + '",')
        terraform_file.append( '                        "' + alias_arn['AliasArn'] + '",')
terraform_file.append( '                    ]')
terraform_file.append( '                }')
terraform_file.append( '            }')
terraform_file.append( '        },')
terraform_file.append( '        {')
terraform_file.append( '            "Effect": "Deny",')
terraform_file.append( '            "Action": [')
terraform_file.append( '                "secretsmanager:CreateSecret",')
terraform_file.append( '                "secretsmanager:UpdateSecret"')
terraform_file.append( '            ],')
terraform_file.append( '            "Resource": "*",')
terraform_file.append( '            "Condition": {')
terraform_file.append( '                "StringNotEquals": {')
terraform_file.append( '                    "secretsmanager:KmsKeyId": [')
for index, alias_arn in enumerate(cmk_aliases['Aliases'], 1):
    if len(cmk_aliases['Aliases']) == index:
        terraform_file.append( '                        "arn:aws-us-gov:kms:us-gov-west-1:' + account_id + ':key/' + alias_arn['TargetKeyId'] + '",')
        terraform_file.append( '                        "' + alias_arn['AliasArn'] + '"')
    else:
        terraform_file.append( '                        "arn:aws-us-gov:kms:us-gov-west-1:' + account_id + ':key/' + alias_arn['TargetKeyId'] + '",')
        terraform_file.append( '                        "' + alias_arn['AliasArn'] + '",')
terraform_file.append( '                    ]')
terraform_file.append( '                }')
terraform_file.append( '            }')
terraform_file.append( '        }')

terraform_file.append( '    ]')
terraform_file.append( '}')
terraform_file.append( 'EOF')
terraform_file.append( '}')
terraform_file.append( '')
terraform_file.append( '###############')
terraform_file.append( '# Attach Policy')
terraform_file.append( '')
terraform_file.append( 'resource "aws_iam_policy_attachment" "attach_Enforce_Encryption" {')
terraform_file.append( '    name = "_Enforce_Encryption"')
terraform_file.append( '    roles = concat(')
terraform_file.append( '        var.tc-r-enforce-s3-encryption,')
terraform_file.append( '        var.mt-r-enforce-encryption,')
terraform_file.append( '        [')
terraform_file.append( '            aws_iam_role.devops.name,')
terraform_file.append( '            aws_iam_role.dvcldsysadmin.name,')
terraform_file.append( '            aws_iam_role.eadvcldsysadmin.name,')
terraform_file.append( '            aws_iam_role.auditor.name,')
terraform_file.append( '            aws_iam_role.costmanager.name,')
terraform_file.append( '            aws_iam_role.tenantsysadmin.name,')
terraform_file.append( '            aws_iam_role.projectowner.name,')
terraform_file.append( '            aws_iam_role.instance_devops.name,')
terraform_file.append( '            aws_iam_role.instance_tenantsysadmin.name,')
terraform_file.append( '            aws_iam_role.service_redshift.name')
terraform_file.append( '        ]')
terraform_file.append( '    )')
terraform_file.append( '    users = concat(')
terraform_file.append( '        var.tc-u-enforce-s3-encryption,')
terraform_file.append( '        var.mt-u-enforce-encryption,')
terraform_file.append( '        [')
terraform_file.append( '        ]')
terraform_file.append( '    )')
terraform_file.append( '    policy_arn = aws_iam_policy._Enforce_Encryption.arn')
terraform_file.append( '}')

#for line in terraform_file:
#    print(line)

# Determine if the file exists and needs to be updated.
print('Checking for existing file')
try:
    previous_terraform_file = read_policy(path)
    print('File exists')
except:
    print('No File found')
    previous_terraform_file = []

if previous_terraform_file == terraform_file:
        print('Terraform file is up to date. No Change made')
else:
    print('Writing new Terraform file.')
    write_policy(terraform_file, path)
