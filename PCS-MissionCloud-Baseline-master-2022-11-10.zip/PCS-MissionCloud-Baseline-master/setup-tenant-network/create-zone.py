import boto3
import subprocess
import shlex
import sys
import os
import json
from botocore.exceptions import ClientError
from subprocess import SubprocessError

# User defined variables
csr_image_id = 'ami-0051d4af5830862d1'
tenant_profile_name = 'saml'
common_services_profile_name = 'common'
common_service_tr_table = '<redacted>'

if sys.platform.lower().startswith('win'):
    terraform_plugin_dir = r'\\us.ray.com\iis\gar\IT\SIPS Control\Documentation\DevCloud\Automation\terraform.d\.terraform\plugins\windows_amd64'
else:
    terraform_plugin_dir = ''

################################################################################
# Definitions

# Definition to move up one directory
def up_dir(cwd):
    new_dir = os.path.dirname(cwd)
    return new_dir

# Definition to find the depth from end a specific folder is in a path
def folder_depth(cwd, folder):
    depth_to_folder = 0
    if '\\' in cwd:
        parts = cwd.split('\\')
    elif '/' in cwd:
        parts = cwd.split('/')
    else:
        parts = []
    for index, part in enumerate(parts[::-1], 1):
        if part == folder:
            depth_to_folder = index
    return depth_to_folder

# Definition to format subprocess arguements for the appropriate OS
def format_subprocess_args(command_line):
    if sys.platform.lower().startswith('win'):
        args = shlex.split(command_line)
    else:
        if command_line.startswith('python '):
            lnx_python3_command = command_line.replace('python', 'python3', 1)
            args = shlex.split(lnx_python3_command)
        else:
            args = shlex.split(command_line)
    return args

# Start using the temporary token and create the encrypted images
session_c = boto3.Session(profile_name=common_services_profile_name)

# Retrieve account number
try:
    sts_client_c = session_c.client('sts')
    account_num = sts_client_c.get_caller_identity()['Account']
    if account_num != "<redacted>":
        print()
        print('Credntials for Common Services are not correct. Re-run get-2-token,py')
        print('and select the Tenant Account first and Comman Services account second')
        print()
        exit()
except ClientError as e:
    if e.response['Error']['Code'] == 'ExpiredToken':
        print()
        print('Error: Expired Token. Please use get-2-token.py to retrieve a new temporay token.')
        print()
    else:
        print('Unexpected error: %s' % e)
    exit()

input_valid = False
while not input_valid:
    print('Type the name of the tenant VPC followed by [ENTER]:')
    print('Example: VPC001')
    vpc_name = input()

    # intialize some variables
    cidr_split = [ 0, 0, 0, 0]
    delimitor = '.'

    # Get tenant number from end of tenant name
    try:
        if vpc_name.lower() == 'testvpc':
            tenant_num = int(0)
        else:
            tenant_num = int(vpc_name[-3:])
    except ValueError:
        print('Error: VPC name not valid.')
        print()
        exit()

    # Determine which Class b subnet to utilize for TME
    if tenant_num >= 0 and tenant_num < 64:
        third_octet = tenant_num * 4
        cidr_split[0] = '10'
        cidr_split[1] = '100'
    elif tenant_num >= 64 and tenant_num <= 124:
        third_octet = (tenant_num - 64) * 4
        cidr_split[0] = '10'
        cidr_split[1] = '101'
    else:
        print()
        print('Error: Tenant number is outside the acceptable range for standard tenants')
        print()
        exit(1)

    # Calculate TME block
    cidr_split[2] = str(third_octet)
    cidr_split[3] = '0/22'
    tme_ipv4_block = delimitor.join(cidr_split)

    # CSR A Loopbacks
    cidr_split[0] = '10'
    cidr_split[1] = '250'
    cidr_split[2] = str(tenant_num + 11)
    cidr_split[3] = '0/24'
    cn_ipv4_block = delimitor.join(cidr_split)
    cidr_split[2] = '6'
    cidr_split[3] = str((tenant_num * 2) + 3)
    cn_a_loopback = delimitor.join(cidr_split)

    # CSR B Loopbacks
    cidr_split[3] = str((tenant_num * 2) + 4)
    cn_b_loopback = delimitor.join(cidr_split)

    print()
    print('-'*60)
    print('VPC Name:                          ' + vpc_name)
    print()
    print('Common Net VPC IPv4 block:         ' + cn_ipv4_block)
    print('Tenant Managed VPC IPv4 block:     ' + tme_ipv4_block)
    print()
    print('CSR-A Management:                  ' + cn_a_loopback)
    #print('Tunnel 100 CSR-A loopback:         ' + tun100_loopback_a)
    print('-'*60)
    print('Are these correct? (Yes/No)')

    yes = set(['yes','y', 'ye'])
    no = set(['no','n'])

    choice = input().lower()
    ask_resp = False
    while not ask_resp:
        if choice in yes:
            input_valid = True
            ask_resp = True
        elif choice in no:
            input_valid = False
            ask_resp = True
        else:
            print("Please respond with 'yes' or 'no'")
            ask_resp = False
            choice = input().lower()

    print()

# Start using the temporary token and create the encrypted images
session = boto3.Session(profile_name=tenant_profile_name)

# Initialze an ec2 session
ec2_client = session.client('ec2')

# Generating the variables file for Terraform
try:
    subprocess.run(format_subprocess_args('python generate-variables.py --profile ' + tenant_profile_name + ' --tenant ' + vpc_name + ' --image ' + csr_image_id +  ' --accept'))
except SubprocessError as e:
    print(e)

try:
    print()
    print('Processing Terraform configs...')
    subprocess.run(format_subprocess_args('terraform apply -auto-approve'))
except SubprocessError as e:
    print(e)

com_rtr_a=subprocess.getoutput('terraform output csr_a_id')

# Figure out the path for current directory and the path to the IAM policies
# 
current_dir = os.getcwd()
dir_depth = folder_depth(current_dir, 'Network')
if dir_depth > 0:
    iam_dir = current_dir
    for index in range(0,dir_depth):
        iam_dir = up_dir(iam_dir)
    iam_dir = os.path.join(iam_dir, 'Federation')
    iam_dir = os.path.join(iam_dir, vpc_name.lower())


    subprocess.run(format_subprocess_args('python update-dynamic-policies.py --profile ' + tenant_profile_name), cwd=iam_dir)
    subprocess.run(format_subprocess_args('terraform apply -auto-approve -var profile=' + tenant_profile_name), cwd=iam_dir)

else:
    print('Current working directory appears to be mapped to the Network folder.')
    print('Please modify your mapped drive to be at least one level up so that')
    print('Network and Federation folders can be seen in a directory listing.')

# Wait for the CSR to be fully up
instance_waiter = ec2_client.get_waiter('instance_status_ok')
try:
    print()
    print('Waiting for CSR to complete its first time boot ...')
#    instance_waiter.wait(InstanceIds=[com_rtr_a, priv_rtr_a])
    instance_waiter.wait(InstanceIds=[com_rtr_a])
except SubprocessError as e:
    print(e)

print()
print('Create Zone script has completed.')
print()