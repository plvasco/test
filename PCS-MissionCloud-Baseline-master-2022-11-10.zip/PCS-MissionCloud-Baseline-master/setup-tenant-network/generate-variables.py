import json
import argparse
import boto3

# Command line variables
parser = argparse.ArgumentParser()
parser.add_argument('-t', '--tenant', help='Tenant Number - Example VPC001', required = True)
parser.add_argument('-p', '--profile', help='Access Profile')
parser.add_argument('-i', '--image', help='Image ID to use for the CSR')
parser.add_argument('-s', '--size', help='Instance size to use for the CSR. Example: c4.large')
parser.add_argument('-a', '--accept', help='Auto accept changes', action='store_true')
parser.add_argument('-k', '--key_rotate', help='Add the new key for rotation', action='store_true' )
parser.add_argument('-o', '--oldest_key', help='Find oldest key and store as default key.', action='store_true')
args = parser.parse_args()

vpc_name = args.tenant
#cn_vpc_id = args.vpc

if not args.image:
    csr_ami_id = "ami-0051d4af5830862d1"
else:
    csr_ami_id = args.image

if not args.size:
    csr_size = "c5.large"
else:
    csr_size = args.size

if not args.profile:
    tenant_profile_name = 'saml'
else:
    tenant_profile_name = args.profile

auto_accept = args.accept

both_keys = args.key_rotate

if args.oldest_key and both_keys == True:
    print('Error: You can not use both -k, --key_rotate and -o, --oldest_key flags')
    print()
    exit(1)
else:
    old_key = args.oldest_key

# Find Tenant's CMK alias
# Start using the temporary token and create the encrypted images
session = boto3.Session(profile_name=tenant_profile_name)

# Initialze an kms session
kms_client = session.client('kms')

################################################
# Find the newest CMK key to use for the account

# Check for enabled key state
def key_state(key_id):
    kms_key_response = kms_client.describe_key(KeyId = key_id)
    kms_state = kms_key_response['KeyMetadata']['KeyState']
    if kms_state == 'Enabled':
        return True
    else:
        return False

# Return all kms aliases
kms_client = session.client('kms')
alias_responses = kms_client.list_aliases()

# Copy only enabled aliases with -CMK- in the name
cmk_aliases = {'Aliases':[]}
for alias in alias_responses['Aliases']:
    state = False
    if '-CMK-' in alias['AliasName']:
        state = key_state(alias['AliasArn'])
        if state:
            cmk_aliases['Aliases'].append(alias)

# Error Check if no enable CMK found
if len(cmk_aliases['Aliases']) == 0:
    #print('Cannot locate the imported Customer Managed Key for encryption.')
    #print('Verify in the console the alias for the CMK and it is fully enable.')
    #print('exiting script ...')
    #exit(1)
    print('New key will be created')
# If only 1 key found use that for alias arn and key id
elif len(cmk_aliases['Aliases']) == 1:
    cmk_aliasarn = cmk_aliases['Aliases'][0]['AliasArn']
    cmk_keyid = cmk_aliases['Aliases'][0]['TargetKeyId']
# for multiple keys find the newest and set alias arn and key id
else:
    newest_date = 0
    oldest_date = 99999999
    for index, cmk_alias in enumerate(cmk_aliases['Aliases'], 0):
        cmk_aliasarn = cmk_alias['AliasArn']
        cmk_keyid = cmk_alias['TargetKeyId']
        alias_date = int(cmk_aliasarn.split('/')[1].split('-')[2])
        if newest_date < alias_date:
            cmk_state = key_state(cmk_keyid)
            if cmk_state == True:
                newest_date = alias_date
                index_to_use = index
        if oldest_date > alias_date:
            cmk_state = key_state(cmk_keyid)
            if cmk_state == True:
                oldest_date = alias_date
                index_to_use_for_oldest = index
    if newest_date > 0:
        cmk_aliasarn = cmk_aliases['Aliases'][index_to_use]['AliasArn']
        cmk_keyid = cmk_aliases['Aliases'][index_to_use]['TargetKeyId']
    if oldest_date < 99999999:
        cmk_aliasarn_old = cmk_aliases['Aliases'][index_to_use_for_oldest]['AliasArn']
        cmk_keyid_old = cmk_aliases['Aliases'][index_to_use_for_oldest]['TargetKeyId']

## Debugging display of just the -CMK- aliases
#print(json.dumps(cmk_aliases, indent = 4))

# For debugging display the newest CMK alias arn and key id
#print()
#print(cmk_aliasarn)
#print(cmk_keyid)
#if both_keys:
#    print()
#    print(cmk_aliasarn_old)
#    print(cmk_keyid_old)
#    print()

# Find and return the full key arn
if len(cmk_aliases['Aliases']) > 0:
    kms_key_response = kms_client.list_keys()

    for key in kms_key_response['Keys']:
        if cmk_keyid in key['KeyId']:
            cmk_keyarn = key['KeyArn']
        if both_keys:
            if cmk_keyid_old in key['KeyId']:
                cmk_keyarn_old = key['KeyArn']

        
    ## For debugging
    #print(cmk_keyarn)
    #print()
    #if both_keys:
    #    print(cmk_keyarn_old)
    #    print()

    alias = cmk_aliasarn.split('/')
    key_alias = alias[1]

    if both_keys or old_key:
        alias = cmk_aliasarn_old.split('/')
        old_key_alias = alias[1]
else:
    key_alias = 'Tenant' + vpc_name[-3:] + '-CMK'

# Static variables
file = 'variables.tf'
cidr_split = [ 0, 0, 0, 0]
delimitor = '.'

# Definition to write the file
def write_variables(policy, path):
    new_variable_file = open(path, mode='wt')
    for line in policy:
        #print(str(line))
        new_variable_file.write(str(line) + '\n')
    
    new_variable_file.close()

# Definition to read the file
def read_variables(path):
    read_file = open(path, 'r')
    variable_file = read_file.read().splitlines()
    read_file.close()
    return variable_file

# Get tenant number from end of tenant name
try:
    if vpc_name.lower() == 'testvpc':
        tenant_num = int(0)
    else:
        tenant_num = int(vpc_name[-3:])
except ValueError:
    print('Error: VPC name not valid.')
    print()
    exit()

# Initialize an ec2 session
ec2_client = session.client('ec2')

#print()
# Construct Variable File
variable_file = []
variable_file.append( '##################')
variable_file.append( '# Access variables')
variable_file.append( '')
variable_file.append( 'variable "region" {')
variable_file.append( '    default = "us-gov-west-1"')
variable_file.append( '}')
variable_file.append( '')
variable_file.append( 'variable "profile" {')
variable_file.append( '    default = "saml"')
variable_file.append( '}')
variable_file.append( '')
variable_file.append( 'variable "profile-remote" {')
variable_file.append( '    default = "common"')
variable_file.append( '}')
variable_file.append( '')
variable_file.append( '###########################')
variable_file.append( '# Common Services Variables')
variable_file.append( '')
variable_file.append( 'variable "cs_account_id" {')
variable_file.append( '    default = "<redacted>"')
variable_file.append( '}')
variable_file.append( '')
variable_file.append( 'variable "cs_transit_vpc" {')
variable_file.append( '    default = "<redacted>"')
variable_file.append( '}')
variable_file.append( '')
variable_file.append( 'variable "cs_transit_cidr" {')
variable_file.append( '    default = "172.31.14.96/27"')
variable_file.append( '}')
variable_file.append( '')
variable_file.append( 'variable "cs_transit_route_table" {')
variable_file.append( '    default = "<redacted>"')
variable_file.append( '}')
variable_file.append( '')
variable_file.append( '##################')
variable_file.append( '# Tenant Variables')
variable_file.append( '')
variable_file.append( 'variable "tenant_number" {')
variable_file.append( '    default = "{0:03d}"'.format(tenant_num))
variable_file.append( '}')
variable_file.append( '')
variable_file.append( 'variable "csr_instance_type" {')
variable_file.append( '    default = "' + csr_size + '"')
variable_file.append( '}')
variable_file.append( '')
variable_file.append( 'variable "csr_ami" {')
variable_file.append( '    default = "' + csr_ami_id + '"')
variable_file.append( '}')
variable_file.append( '')
variable_file.append( 'variable "key_alias" {')
if old_key:
    variable_file.append( '    default = "' + old_key_alias + '"')
else:
    variable_file.append( '    default = "' + key_alias + '"')
variable_file.append( '}')
variable_file.append( '')
if both_keys:
    variable_file.append( 'variable "old_key_alias" {')
    variable_file.append( '    default = "' + old_key_alias + '"')
    variable_file.append( '}')
    variable_file.append( '')



#for line in variable_file:
#    print(line)


#Read in previous variable file
previous_variable_file = read_variables(file)

# Compare files and write if update is needed
if previous_variable_file == variable_file:
        print('Variable file is up to date. No Change made.')
else:
    if auto_accept == False:
        print('*'*50)
        print('Changes detected')
        print('*'*50)
        
        index = 0
        for line in previous_variable_file:
            if line != variable_file[index]:
                print(line, '=>', variable_file[index])
            index = index + 1
        print()
        
        input_valid = False
        while not input_valid:

            print('Save Changes? (Yes/No)')

            yes = set(['yes','y', 'ye'])
            no = set(['no','n'])

            choice = input().lower()
            if choice in yes:
                print('Updating Variable file.')
                write_variables(variable_file, file)
                input_valid = True
            elif choice in no:
                print('Discarding changes.')
                input_valid = True
            else:
                print("Please respond with 'yes' or 'no'")
                input_valid = False
                choice = input().lower()
    else:
        print('Updating Variable file.')
        write_variables(variable_file, file)
