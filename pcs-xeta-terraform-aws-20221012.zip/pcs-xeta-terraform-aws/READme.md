## Note Pietto
See [examples](https://github.ids.ray.com/IDS/pcs-xeta-terraform-aws/tree/development/examples) directory for working examples to reference.

## Terraform Modules test

Terraform modules are reusable code that can be called to provision resources in AWS. The following modules are available for use.

## pcs-xeta-terraform-aws


NOTE: if ```adjoin_flag``` is set to ```true```, terraform must be called with ``` -var "adjoin_password=<adjoin-password>" ```

| Module Name | Purpose | Directory |
|--------------|---------|-----------|
| Build Modules | This directory contain modules to buid services needed. This is where parameters can be changed and used to build the configured services in the following directories | ./build-modules |
| Data Module | Used to gather existing data from within the VPC. Includes subnets, AMI, and security groups | ./data-source |
| Security Group Module | Used to create baseline security groups in a VPC  | ./security-group |
| Linux Module | Used to build a linux instance from an ami that can be joined to the domain. This module includes EFS and EBS,  | ./linux |
| KMS Module | used to create KMS key for encryption. To provison KMS, go to ./build-modules/kms-build | ./KMS  |
| Storage Module | contain configurations to build sorage services. This includes FSX-ONTAP, S3, storage gateway | ./storage  |
| RDS Module | Used to create an rds instance of Oracle, Postgres or MySQL | ./rds-build |

| Windows Module | Used to build a windows instance from an ami that can be joined to the domain | ./windows-build |

## Demo
  
The entire repo can be pulled to be used as a demo. Changes can be made in the .tf files in the build directories for any demo you like. 

## Sample main.tf

  
The following example shows how to call child modules in another module and referencing outputs in Terraform. Please see the module README for the expected inputs and available outputs.  
  
```hcl

module "data-source" {
  source                  = "../data-source"
  vpc_id                  = var.vpc_id
  ami_name                = var.ami_name
}

resource "aws_instance" "linux_instance" {
  ami                           = module.data-source.ami_id
  instance_type                 = var.ec2_type
  user_data                     = "${base64encode(data.template_file.bootstrap.rendered)}"
  subnet_id                     = "${module.data-source.priv_1_subnet}"
  key_name                      = "${aws_key_pair.ec2_key.id}"
  vpc_security_group_ids        = [module.data-source.platformsg]
}
```
RAYTHEON PROPRIETARY

This document contains data or information proprietary to Raytheon Company and is restricted to use only by persons authorized by Raytheon Company in writing to use it. Disclosure to unauthorized persons would likely cause substantial competitive harm to Raytheon Company's business position.

Neither said document nor its contents shall be furnished or disclosed to or copied or used by persons outside Raytheon Company without the express written approval of Raytheon Company.

WARNING – This repository contains Technical Data and / or technology whose export or disclosure to Non-U.S. Persons, wherever located, is restricted by the International Traffic in Arms Regulations (ITAR) (22 C.F.R. Section 120-130) or the Export Administration Regulations (EAR) (15 C.F.R. Section 730-774).

This document CANNOT be exported (e.g., provided to a supplier outside of the United States) or disclosed to a Non-U.S. Person, wherever located, until a final Jurisdiction and Classification determination has been completed and approved by Raytheon, and any required U.S. Government approvals have been obtained.

Violations are subject to severe criminal penalties.

Unpublished Work - Copyright Raytheon Company. (UNCLASSIFIED)

