Configuration in this directory creates:

- FSX OnTap file system
- FSX OnTap storage virtual machine
- FSX OnTap volume



## Usage

To run this you need to execute:

```bash
$ terraform init
$ terraform plan
$ terraform apply
```
